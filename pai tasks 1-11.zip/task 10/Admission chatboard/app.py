from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Chatbot Responses
responses = {
    "admission": "Admissions are open for Fall 2026.",
    "deadline": "The last date to apply is 30 August 2026.",
    "programs": "We offer BSCS, BSAI, BSIT, and BBA programs.",
    "fee": "The average semester fee is 85,000 PKR.",
    "scholarship": "Yes, merit-based scholarships are available.",
    "hostel": "Hostel facility is available for boys and girls.",
    "contact": "You can contact us at admissions@university.com"
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot():
    user_message = request.form["msg"].lower()

    reply = "Sorry, I don't understand."

    for key in responses:
        if key in user_message:
            reply = responses[key]
            break

    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True)