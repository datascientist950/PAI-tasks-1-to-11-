const cityInput  = document.getElementById("city-input");
const searchBtn  = document.getElementById("search-btn");
const errorMsg   = document.getElementById("error-msg");
const weatherSec = document.getElementById("weather-section");
const loadingEl  = document.getElementById("loading");

function showError(msg) {
  errorMsg.textContent = msg;
  errorMsg.classList.remove("hidden");
  weatherSec.classList.add("hidden");
  loadingEl.classList.add("hidden");
}

function hideError() {
  errorMsg.classList.add("hidden");
}

function showLoading() {
  loadingEl.classList.remove("hidden");
  weatherSec.classList.add("hidden");
  hideError();
}

function hideLoading() {
  loadingEl.classList.add("hidden");
}

function setText(id, val) {
  document.getElementById(id).textContent = val;
}

async function fetchWeather(city) {
  showLoading();
  try {
    const res  = await fetch(`/weather?city=${encodeURIComponent(city)}`);
    const data = await res.json();

    if (!res.ok) {
      showError(data.error || "Something went wrong.");
      return;
    }

    populateWeather(data);
  } catch (err) {
    showError("Network error — make sure Flask is running.");
  } finally {
    hideLoading();
  }
}

function populateWeather(d) {
  setText("city-name",   d.city);
  setText("country",     d.country);
  setText("temp",        d.temp);
  setText("feels-like",  `${d.feels_like}°C`);
  setText("humidity",    `${d.humidity}%`);
  setText("wind",        `${d.wind_speed} km/h`);
  setText("pressure",    `${d.pressure} hPa`);
  setText("description", d.description);
  setText("weather-icon", d.icon);

  const grid = document.getElementById("forecast-grid");
  grid.innerHTML = "";
  (d.forecast || []).forEach(day => {
    const card = document.createElement("div");
    card.className = "forecast-day";
    card.innerHTML = `
      <div class="f-day">${day.day}</div>
      <div class="f-icon">${day.icon}</div>
      <div class="f-temp">${day.temp}°C</div>
    `;
    grid.appendChild(card);
  });

  weatherSec.classList.remove("hidden");
}

searchBtn.addEventListener("click", () => {
  const city = cityInput.value.trim();
  if (!city) { showError("Please enter a city name."); return; }
  fetchWeather(city);
});

cityInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") searchBtn.click();
});

window.addEventListener("DOMContentLoaded", () => {
  fetchWeather("Lahore");
});