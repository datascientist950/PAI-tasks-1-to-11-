from flask import Flask, render_template, request, jsonify
from datetime import datetime
import requests

app = Flask(__name__)

API_KEY = "7283761b406f871484b51ee4b459979c"
BASE_URL = "https://api.openweathermap.org/data/2.5"


def get_weather_icon(condition):
    icons = {
        "Clear": "☀️", "Clouds": "⛅", "Rain": "🌧️",
        "Drizzle": "🌦️", "Thunderstorm": "⛈️", "Snow": "❄️",
        "Mist": "🌫️", "Fog": "🌫️", "Haze": "🌫️",
    }
    return icons.get(condition, "🌡️")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/weather")
def weather():
    city = request.args.get("city", "").strip()
    if not city:
        return jsonify({"error": "City name is required"}), 400

    current_url = f"{BASE_URL}/weather?q={city}&appid={API_KEY}&units=metric"
    cur_res = requests.get(current_url, timeout=5)

    if cur_res.status_code == 404:
        return jsonify({"error": f"City '{city}' not found"}), 404
    if cur_res.status_code != 200:
        return jsonify({"error": "Failed to fetch weather data"}), 500

    cur = cur_res.json()

    forecast_url = f"{BASE_URL}/forecast?q={city}&appid={API_KEY}&units=metric&cnt=40"
    fore_res = requests.get(forecast_url, timeout=5)
    forecast_data = []

    if fore_res.status_code == 200:
        fore = fore_res.json()
        seen_dates = set()
        for item in fore["list"]:
            date = item["dt_txt"].split(" ")[0]
            time = item["dt_txt"].split(" ")[1]
            if date not in seen_dates and time == "12:00:00":
                seen_dates.add(date)
                day_name = datetime.strptime(date, "%Y-%m-%d").strftime("%a")
                forecast_data.append({
                    "day": day_name,
                    "temp": round(item["main"]["temp"]),
                    "icon": get_weather_icon(item["weather"][0]["main"]),
                    "description": item["weather"][0]["description"],
                })
            if len(forecast_data) == 5:
                break

    result = {
        "city": cur["name"],
        "country": cur["sys"]["country"],
        "temp": round(cur["main"]["temp"]),
        "feels_like": round(cur["main"]["feels_like"]),
        "humidity": cur["main"]["humidity"],
        "pressure": cur["main"]["pressure"],
        "wind_speed": round(cur["wind"]["speed"] * 3.6),
        "description": cur["weather"][0]["description"],
        "condition": cur["weather"][0]["main"],
        "icon": get_weather_icon(cur["weather"][0]["main"]),
        "forecast": forecast_data,
    }
    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True)