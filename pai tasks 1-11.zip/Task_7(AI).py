from flask import Flask, jsonify, request
import requests
from datetime import datetime, timezone, timedelta

app = Flask(__name__)

API_KEY = "18699046af8113add3859f8fad3932d0"
OWM_BASE = "https://api.openweathermap.org/data/2.5"

PK_TIMEZONE = timezone(timedelta(hours=5))

PAK_CITIES = [
    "Lahore", "Karachi", "Islamabad", "Rawalpindi", "Peshawar",
    "Quetta", "Multan", "Faisalabad", "Hyderabad", "Sialkot",
    "Gujranwala", "Bahawalpur", "Sargodha", "Abbottabad", "Murree",
]

SLOTS = {
    "morning":   (5, 11),
    "afternoon": (12, 16),
    "evening":   (17, 20),
    "night":     (21, 4),
}

def get_time_slot(hour):
    if 5 <= hour <= 11:
        return "morning"
    elif 12 <= hour <= 16:
        return "afternoon"
    elif 17 <= hour <= 20:
        return "evening"
    return "night"

def make_summary(main_condition, description, humidity, wind_speed_kph, rain_chance=0):
    cond = main_condition.lower()
    msg = ""

    if "thunderstorm" in cond:
        msg = "Thunderstorm expected"
    elif "drizzle" in cond:
        msg = "Light drizzle expected"
    elif "rain" in cond or rain_chance > 60:
        msg = "Rain expected"
    elif rain_chance > 30:
        msg = "Possible light rain"
    elif "snow" in cond:
        msg = "Snow expected"
    elif any(x in cond for x in ("mist", "fog", "haze")):
        msg = "Foggy or hazy conditions"
    elif "clear" in cond:
        msg = "Clear but windy" if wind_speed_kph > 20 else "Clear sky"
    elif "cloud" in cond:
        msg = "Partly cloudy" if any(x in description for x in ("few", "scattered")) else "Cloudy"
    else:
        msg = description.title()

    if humidity > 80:
        msg += " | very humid"
    elif humidity > 60:
        msg += " | humid"

    if wind_speed_kph > 30:
        msg += " | strong wind"
    elif wind_speed_kph > 15:
        msg += " | moderate wind"

    return msg

def fetch_forecast(city):
    response = requests.get(f"{OWM_BASE}/forecast", params={
        "q": f"{city},PK",
        "appid": API_KEY,
        "units": "metric",
        "cnt": 40
    })
    return response

def parse_weather(entry):
    utc_time = datetime.fromtimestamp(entry["dt"], tz=timezone.utc)
    local_time = utc_time.astimezone(PK_TIMEZONE)
    weather = entry["weather"][0]
    wind_kph = round(entry["wind"]["speed"] * 3.6)
    rain_pct = round(entry.get("pop", 0) * 100)

    return local_time, {
        "date": local_time.strftime("%A, %d %b"),
        "time": local_time.strftime("%I:%M %p"),
        "temperature": round(entry["main"]["temp"]),
        "feels_like": round(entry["main"]["feels_like"]),
        "humidity": entry["main"]["humidity"],
        "condition": weather["main"],
        "description": weather["description"].title(),
        "wind_speed": wind_kph,
        "rain_chance": rain_pct,
        "summary": make_summary(weather["main"], weather["description"],
                                entry["main"]["humidity"], wind_kph, rain_pct),
    }

@app.route("/weather")
def weather_by_slot():
    city = request.args.get("city", "Lahore").strip().title()
    slot = request.args.get("time", "morning").strip().lower()

    if slot not in SLOTS:
        return jsonify({"error": "Invalid time value"}), 400

    resp = fetch_forecast(city)
    data = resp.json()

    if resp.status_code != 200:
        return jsonify({"error": "City not found"}), 404

    results = []
    for entry in data["list"]:
        local_time, info = parse_weather(entry)
        if get_time_slot(local_time.hour) == slot:
            results.append(info)

    if not results:
        return jsonify({"message": "No data available"})

    return jsonify({
        "city": data["city"]["name"],
        "country": "Pakistan",
        "time_slot": slot,
        "results": results
    })

@app.route("/weather/day")
def weather_full_day():
    city = request.args.get("city", "Lahore").strip().title()
    resp = fetch_forecast(city)
    data = resp.json()

    if resp.status_code != 200:
        return jsonify({"error": "City not found"}), 404

    day_dict = {}
    for entry in data["list"]:
        local_time, info = parse_weather(entry)
        day_label = local_time.strftime("%A, %d %b")
        slot = get_time_slot(local_time.hour)

        day_dict.setdefault(day_label, {})
        if slot not in day_dict[day_label]:
            day_dict[day_label][slot] = info

    output = [
        {
            "date": day,
            "morning": slots.get("morning", "No data"),
            "afternoon": slots.get("afternoon", "No data"),
            "evening": slots.get("evening", "No data"),
            "night": slots.get("night", "No data"),
        }
        for day, slots in day_dict.items()
    ]

    return jsonify({
        "city": data["city"]["name"],
        "country": "Pakistan",
        "days": output
    })

@app.route("/weather/now")
def weather_current():
    city = request.args.get("city", "Lahore").strip().title()
    resp = requests.get(f"{OWM_BASE}/weather", params={
        "q": f"{city},PK",
        "appid": API_KEY,
        "units": "metric",
    })
    data = resp.json()

    if resp.status_code != 200:
        return jsonify({"error": "City not found"}), 404

    now = datetime.now(PK_TIMEZONE)
    weather = data["weather"][0]
    wind_kph = round(data["wind"]["speed"] * 3.6)

    return jsonify({
        "city": data["name"],
        "country": "Pakistan",
        "current_time": now.strftime("%I:%M %p"),
        "time_slot": get_time_slot(now.hour),
        "temperature": round(data["main"]["temp"]),
        "feels_like": round(data["main"]["feels_like"]),
        "humidity": data["main"]["humidity"],
        "condition": weather["main"],
        "description": weather["description"].title(),
        "wind_speed": wind_kph,
        "visibility": round(data.get("visibility", 0)/1000, 1),
        "summary": make_summary(weather["main"], weather["description"],
                                data["main"]["humidity"], wind_kph)
    })

@app.route("/cities")
def city_list():
    return jsonify({"cities": PAK_CITIES})

if __name__ == "__main__":
    app.run(debug=True, port=5000)