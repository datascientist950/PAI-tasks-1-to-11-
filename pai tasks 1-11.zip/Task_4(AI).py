class NQueenSolver:
    def __init__(self, n):
        self.n = n
        self.solutions = []

        self.cols_used = set()
        self.diag1_used = set()
        self.diag2_used = set()

    def solve(self):
        self._backtrack([], 0)
        return self.solutions

    def _backtrack(self, config, row):
        if row == self.n:
            self.solutions.append(config[:])
            return

        for col in range(self.n):
            if col in self.cols_used:
                continue
            if (row - col) in self.diag1_used:
                continue
            if (row + col) in self.diag2_used:
                continue

            self.cols_used.add(col)
            self.diag1_used.add(row - col)
            self.diag2_used.add(row + col)
            config.append(col)

            self._backtrack(config, row + 1)

            # backtrack
            self.cols_used.remove(col)
            self.diag1_used.remove(row - col)
            self.diag2_used.remove(row + col)
            config.pop()

    def print_board(self, solution, idx):
        line = " +" + "---+" * self.n
        print(f"\nSolution {idx}:")
        print(line)

        for r, q_col in enumerate(solution):
            row_view = " |"
            for c in range(self.n):
                row_view += " Q |" if c == q_col else " . |"
            print(row_view)
            print(line)

        print("  " + "  ".join(str(i) for i in range(self.n)))

    def show_all(self):
        print(f"\nBoard : {self.n} × {self.n}")
        print(f"Solutions found : {len(self.solutions)}")

        for i, sol in enumerate(self.solutions, start=1):
            self.print_board(sol, i)


def show_steps(solution, size):
    """Display placement step by step"""
    print("\nStep-by-Step Queen Placement")
    board = [['.' for _ in range(size)] for _ in range(size)]

    for step, col in enumerate(solution):
        board[step][col] = 'Q'
        line = " +" + "---+" * size

        print(f"\nStep {step + 1}  —  Row {step}, Col {col}")
        print(line)

        for r in range(size):
            row_line = " |" + "".join(f" {board[r][c]} |" for c in range(size))
            print(row_line)
            print(line)


if __name__ == "__main__":
    size = 6
    print(f"=== {size}-Queens Solver ===")

    solver = NQueenSolver(size)
    sols = solver.solve()
    solver.show_all()

    if sols:
        show_steps(sols[0], size)