# NLP Tokenization Example

from nltk.tokenize import word_tokenize
import nltk

# Download tokenizer package
nltk.download('punkt')

# Input sentence
text = "Artificial Intelligence is changing the world."

# Tokenization
tokens = word_tokenize(text)

# Output
print("Original Text:")
print(text)

print("\nTokens:")
print(tokens)