import re
import requests
from bs4 import BeautifulSoup
import openpyxl


def extract_emails_from_url(link):
    response = requests.get(link)
    parsed_data = BeautifulSoup(response.text, "html.parser")
    page_text = parsed_data.get_text()

    email_pattern = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    found_emails = set(re.findall(email_pattern, page_text))

    return list(found_emails)


def save_to_excel(email_list):
    workbook = openpyxl.Workbook()
    sheet = workbook.active

    sheet.append(["Email"])
    for e in email_list:
        sheet.append([e])

    workbook.save("emails.xlsx")


# main execution
website_link = input("Enter website URL: ").strip()
email_data = extract_emails_from_url(website_link)

save_to_excel(email_data)

print(f"Done! {len(email_data)} email(s) saved to emails.xlsx")