def water_jug_dfs(cap1, cap2, target):
    """
    Water Jug problem using DFS approach
    cap1  : capacity of jug 1
    cap2  : capacity of jug 2
    target: required litres in jug 1
    """

    start_state = (0, 0)
    visited_states = set([start_state])

    stack = [(start_state, [(start_state, "Start — both jugs empty")])]

    print("=" * 60)
    print("  Depth-First Search : Water Jug Problem")
    print(f"  Jug-1 holds up to : {cap1} L")
    print(f"  Jug-2 holds up to : {cap2} L")
    print(f"  We need           : {target} L in Jug-1")
    print("=" * 60)

    while stack:
        state, path = stack.pop()
        x, y = state

        if x == target:
            print(">>> Solution found!\n")
            print(f"  {'#':<4} {'Jug-1':>7} {'Jug-2':>7}   Action")
            print("  " + "-" * 52)

            for i, (st, act) in enumerate(path):
                print(f"  {i:<4} {st[0]:>6}L {st[1]:>6}L   {act}")

            print(f"\n  Done — Jug-1 has exactly {target} litres.")
            print("=" * 60)
            return

        next_moves = []

        if x < cap1:
            next_moves.append(((cap1, y), "Action 1 : Fill Jug-1 to full"))

        if y < cap2:
            next_moves.append(((x, cap2), "Action 2 : Fill Jug-2 to full"))

        if x > 0:
            next_moves.append(((0, y), "Action 3 : Empty Jug-1"))

        if y > 0:
            next_moves.append(((x, 0), "Action 4 : Empty Jug-2"))

        if x > 0 and y < cap2:
            transfer = min(x, cap2 - y)
            next_moves.append(((x - transfer, y + transfer),
                               f"Action 5 : Move {transfer}L  Jug-1 → Jug-2"))

        if y > 0 and x < cap1:
            transfer = min(y, cap1 - x)
            next_moves.append(((x + transfer, y - transfer),
                               f"Action 6 : Move {transfer}L  Jug-2 → Jug-1"))

        for new_state, action in next_moves:
            if new_state not in visited_states:
                visited_states.add(new_state)
                stack.append((new_state, path + [(new_state, action)]))

    print("No path to the target exists with these jug sizes.")
    print("=" * 60)


if __name__ == "__main__":
    water_jug_dfs(cap1=4, cap2=3, target=2)